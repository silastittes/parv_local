rm Makefile
cp makefiles/Makefile.DEFAULT Makefile
make clean
make
