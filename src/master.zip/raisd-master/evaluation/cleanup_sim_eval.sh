cd sim_eval
for i in {1..70} 
do
 rm -r d$i
done


