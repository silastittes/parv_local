cd tools
./fetch_install_all.sh
